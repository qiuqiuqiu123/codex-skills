# 事件：{事件名称}

<!-- 复制此文件并重命名为具体事件名，如 order-created.md、user-tier-upgraded.md -->

## 概述

| 属性 | 值 |
|------|------|
| 事件名 | <!-- 如 order.created --> |
| 触发时机 | <!-- 如 订单创建成功后 --> |
| 生产者 | <!-- 如 OrderService --> |
| 消费者 | <!-- 如 NotificationService, AnalyticsService --> |

## Payload Schema

```typescript
interface OrderCreatedEvent {
  eventId: string;      // UUID
  timestamp: string;    // ISO 8601
  // 按需添加字段
}
```

## 消费者行为

| 消费者 | 处理逻辑 | 幂等性 |
|--------|----------|--------|
| | | 是/否 |

## 关联

- 触发流程：[相关流程](../../behavior/flows/xxx.md)
- 来源意图：[业务规则](../../../intent/business-rules/xxx.md)
