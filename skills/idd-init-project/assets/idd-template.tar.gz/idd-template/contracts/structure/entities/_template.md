# 实体：{实体名称}

<!-- 复制此文件并重命名为具体实体名，如 User.md、Order.md -->

## 字段

| 字段 | 类型 | 可空 | 说明 |
|------|------|------|------|
| id | UUID | 否 | 主键 |
| | | | |

## 权威 Schema

<!-- 冲突时以此 schema 为准，表格视图有偏差要修表格 -->

```typescript
interface EntityName {
  id: string; // UUID
}
```

## 约束

<!-- 唯一性、索引、业务约束等 -->

- 

## 关联行为

<!-- 指向 contracts/behavior/ 下的相关场景 -->

- [流程名](../../behavior/flows/xxx.md)

## 意图来源

<!-- 指向 intent/ 下的相关文档 -->

- [业务规则](../../../intent/business-rules/xxx.md)
