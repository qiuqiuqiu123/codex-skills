# API：{模块名称}

<!-- 复制此文件并重命名为具体模块名，如 user-api.md、order-api.md -->

## 端点列表

| 方法 | 路径 | 说明 | 认证 |
|------|------|------|------|
| GET | /api/v1/xxx | | 需要 |
| POST | /api/v1/xxx | | 需要 |

## 权威 Schema

<!-- OpenAPI 片段，冲突时以此为准 -->

```yaml
paths:
  /api/v1/xxx:
    get:
      summary: ""
      parameters: []
      responses:
        '200':
          description: 成功
          content:
            application/json:
              schema:
                type: object
                properties: {}
```

## 错误响应

| 状态码 | 错误码 | 说明 | 详见 |
|--------|--------|------|------|
| 400 | | | [错误码](../../behavior/errors/xxx.md) |

## 关联行为

- [相关流程](../../behavior/flows/xxx.md)

## 意图来源

- [业务规则](../../../intent/business-rules/xxx.md)
