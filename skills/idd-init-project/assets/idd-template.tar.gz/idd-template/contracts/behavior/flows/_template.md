# 流程场景：{场景名称}

<!-- 复制此文件并重命名为具体场景名，如 user-registration.md、checkout.md -->

## 对应意图

- [业务规则](../../../intent/business-rules/xxx.md)
- [流程](../../../intent/workflows/xxx.md)

## 场景列表

### 场景：{正常路径描述}

- Given {前置条件}
- When {用户/系统动作}
- Then {预期结果}
- And {附加断言}

### 场景：{异常路径描述}

- Given {前置条件}
- When {触发异常的动作}
- Then {异常处理结果}
- And {事件/日志}

### 场景：{边界条件描述}

- Given {边界前置条件}
- When {边界动作}
- Then {边界结果}

## 涉及实体

- [实体名](../../structure/entities/xxx.md)

## 涉及事件

- [事件名](../../structure/events/xxx.md)
