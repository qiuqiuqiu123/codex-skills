# 行为规则：{规则组名称}

<!-- 复制此文件并重命名为具体规则组名，如 pricing-rules.md、permission-rules.md -->
<!-- EARS 关键字保留英文：WHEN, SHALL, IF, THEN, WHILE, WHERE -->
<!-- 主体描述使用中文 -->

## 对应意图

- [业务规则](../../../intent/business-rules/xxx.md#章节名)

## 规则

- WHEN {触发条件} the system SHALL {系统行为}
- WHEN {条件A} AND {条件B} the system SHALL {行为}
- IF {异常条件} THEN the system SHALL {降级/兜底行为}
- WHILE {持续条件} the system SHALL {限制行为}
- WHERE {上下文} the system SHALL {特定行为}

## 补充说明

<!-- 规则之间的优先级、冲突处理等 -->

## 实现锚点

<!-- 此段由 agent 维护 -->
<!-- 格式：- src/path/to/file.py:function_name -->
