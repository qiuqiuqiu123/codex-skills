# IDD 项目模板

基于**分层混合意图驱动开发范式（Intent-Driven Development）**的项目脚手架。

## 快速开始

1. 复制此目录到你的项目根目录
2. 填写 `.steering/` 下的宪章、技术栈、编码约定
3. 从 `intent/` 开始编写业务规则和流程
4. 根据意图层内容，在 `contracts/` 下创建结构契约和行为契约
5. 实现代码，在派生函数头部加锚点注释

## 目录结构

```
.steering/              项目级不变约束（最高优先级）
├── constitution.md     冲突仲裁规则、不可违反原则
├── tech-stack.md       技术栈和依赖版本约束
└── conventions.md      编码风格、命名约定、锚点约定

intent/                 意图层（中文，文档为源）
├── domain/glossary.md  术语表
├── business-rules/     业务规则、决策矩阵
├── workflows/          状态机、流程图（Mermaid）
├── personas/           角色定义
└── permissions.md      权限矩阵

contracts/              契约层
├── structure/          结构契约（强形式化）
│   ├── entities/       实体：表格 + 嵌入 Schema
│   ├── apis/           接口：端点表格 + OpenAPI 片段
│   └── events/         事件：payload schema
└── behavior/           行为契约（半形式化）
    ├── flows/          Given/When/Then 场景
    ├── rules/          EARS 语句
    └── errors/         错误码和触发条件

src/                    实现层（代码为源）
├── generated/          从 contracts/structure schema 自动生成，勿手改
└── ...                 业务代码，用锚点回溯文档

.anchors/               锚点索引（agent 维护，勿手改）
├── forward.json        代码 → 文档的正向锚点
└── reverse.json        文档 → 代码的反向索引

.validator/             AI 校验器
└── validator-config.md 校验器 prompt 和阈值配置

.idd/                   事务记录（非业务权威源）
├── changes/            活跃特性和契约变更
├── issues/             Bug 分析、修复和验证
├── releases/           部署计划和线上验证
└── history/            删除、迁移和审计历史
```

## 使用模板文件

每个目录下的 `_template.md` 是模板文件。使用方式：

1. 复制 `_template.md` 并重命名为具体名称（如 `pricing.md`）
2. 按模板结构填写内容
3. 删除占位注释

## 层间优先级

```
.steering > intent > contracts > src
```

冲突时高优先级层为准，低优先级层需修改。如需违反 steering，必须创建 ADR。

## 双语约定

| 位置 | 语言 |
|------|------|
| intent/ 全部 | 中文 |
| contracts/ 说明文本 | 中文 |
| contracts/ Schema/OpenAPI | 英文 |
| contracts/behavior/ EARS/GWT 关键字 | 英文（WHEN, SHALL, Given, Then...） |
| 代码标识符 | 英文 |
| 代码锚点注释指令 | 英文（@intent:, @contract:） |

## 方法论

完整方法论说明见 [docs/idd-methodology.md](../docs/idd-methodology.md)。
