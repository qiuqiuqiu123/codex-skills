# 编码约定

## 命名规范

| 类型 | 风格 | 示例 |
|------|------|------|
| 文件名 | <!-- 如 kebab-case --> | <!-- 如 user-service.py --> |
| 类名 | <!-- 如 PascalCase --> | <!-- 如 UserService --> |
| 函数/方法 | <!-- 如 snake_case --> | <!-- 如 get_user_by_id --> |
| 常量 | <!-- 如 UPPER_SNAKE --> | <!-- 如 MAX_RETRY_COUNT --> |
| 数据库表 | <!-- 如 snake_case 复数 --> | <!-- 如 users --> |

## 项目约定

<!-- 按项目需要填写 -->

- 错误处理策略：<!-- 如 所有异常通过统一中间件捕获 -->
- 日志格式：<!-- 如 JSON structured logging -->
- 测试策略：<!-- 如 单元测试覆盖率 ≥ 80% -->

## IDD 锚点约定

代码中派生自意图/契约的函数/类，头部注释需带锚点：

```
# @intent: intent/business-rules/xxx.md#章节名
# @contract: contracts/behavior/rules/xxx.md#章节名
```

`src/generated/` 下的代码由契约层 schema 自动生成，禁止手改。
